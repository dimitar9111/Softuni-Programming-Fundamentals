﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Average_Grades
{
    class Grades
    {
        public string Name { get; set; }
        public List<double> AllGrades { get; set; }
        public double AverageGrade
        {
            get
            {
                return AllGrades.Average();
            }
        }

    }
}
