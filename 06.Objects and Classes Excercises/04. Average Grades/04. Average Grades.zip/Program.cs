﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Average_Grades
{
    class Program
    {
        static void Main(string[] args)
        {
            var n = int.Parse(Console.ReadLine());
            var studentsGrades = new List<Grades>();
            

            for (int i = 0; i < n; i++)
            {
                var student = new Grades();
                var input = Console.ReadLine().Split().ToList();
                string studentName = input[0];
                student.Name = studentName;
                var grades = new List<double>();
                for (int j = 1; j < input.Count; j++)
                {
                    grades.Add(double.Parse(input[j]));
                }

                student.AllGrades = grades;
                studentsGrades.Add(student);

            }
            
            List<Grades> sortedStudents = studentsGrades.OrderBy(s => s.Name).ThenByDescending(s=>s.AverageGrade).ToList();
            foreach (var studenT in sortedStudents)
            {
                if (studenT.AverageGrade>=5.00)
                {
                    Console.WriteLine($"{studenT.Name} -> {studenT.AverageGrade:f2}");
                }
            }     
        }
    }
}
